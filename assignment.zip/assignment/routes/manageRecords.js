var express = require('express');
var router = express.Router();
var records = require('../jsonData/jsonData.json');
const fs = require("fs"); 
let HttpStatus = require('http-status-codes');
var result = [];
/* GET records listing. */
router.get('/', function(req, res, next) {
    //var records = JSON.parse(recordsJson); 
   // console.log(recordsJson.length);
    if (records && records.length) {
        var idArr =[];
        openArr=[];
        closedCounter=0;
        records.forEach(function (vl, i) {
            idArr.push(vl.id);
            if(vl.disposition=='closed'){
                closedCounter++;
            }else if(vl.disposition=='open'){
                openArr.push(vl);
            }
        });
        result.push({
            Ids :idArr,
            open:openArr,
            closedCount:closedCounter
        });
        res.status(HttpStatus.OK).send(result);
        return;
    } else {
        res.status(HttpStatus.NOT_FOUND).send([]);
        return;
    }

    });



module.exports = router;